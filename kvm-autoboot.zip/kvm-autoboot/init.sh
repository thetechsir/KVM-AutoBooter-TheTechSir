
tput bold
echo  '-------------KVM Auto Boot Systemd Helper--------------'
tput setaf 6 
cat thetechsir.txt
echo
tput setaf 4
tput setaf 3
cat banner.txt
tput setaf 2
tput setaf 7
echo
tput setaf 2
echo  '-------------Select Your Option--------------'
tput setaf 4
echo  '-- 1 create your kvm virt guest start script'
tput setaf 4
echo '-- 2 create&enable systemd service with boot condition'
tput setaf 4
echo '-- 3 dump your manual.conf with new option added for refind'
tput setaf 2
echo  '-------------Select Your Option--------------'
echo  '-------------By' "$(tput setaf 5)TheTechSir" "$(tput setaf 7)--------------"


#select num in 1 2 3 4
#do 
#echo "you have chosen $num"
#if [[ -z "$num" ]]; then
#   printf '%s\n' "No input entered"
#done


read -ep "enter 1 to begin: " numSelect
if [ "$numSelect" == "1" ]
then
read -ep "VM Name Plz:  " vmName
#sudo mkdir /etc/libvirt/auto-kvm/

echo "sudo virsh start ${vmName}" > "/tmp/${vmName}.sh"
sudo chmod +x "/tmp/${vmName}.sh"
sudo cp "/tmp/${vmName}.sh"  "/etc/libvirt/auto-kvm/${vmName}.sh"
echo start script was created here /etc/libvirt/auto-kvm/${vmName}.sh
vmstart=/etc/libvirt/auto-kvm/${vmName}.sh
fi

echo "Create systemd service for this kvm 2"

vmstart=/etc/libvirt/auto-kvm/${vmName}.sh
read -ep "Service Name Plz:  " serviceName
echo $serviceName

touch /tmp/${serviceName}.service

cat <<EOT >> /tmp/${serviceName}.service

[Unit]
Description=${serviceName}-kvm-boot
ConditionKernelCommandLine=${vmName}=0
[Service]
WorkingDirectory=/
Type=oneshot
TimeoutSec=0
RemainAfterExit=yes
ExecStart=/bin/bash -c 'cd / && .${vmstart}'
[Install]
WantedBy=multi-user.target
EOT
sudo mv /tmp/${serviceName}.service /etc/systemd/system/${serviceName}.service
tput setaf 2
cat /etc/systemd/system/${serviceName}.service
sudo systemctl enable $serviceName
echo 
echo 
tput setaf 7
echo now simply add ${vmName}=0 to your bootloader, guest will only boot when 
echo your bootloader has this line in it. 
echo enjoy!
echo 
echo
tput setaf 4
sudo systemctl status $serviceName





